/* #define TWSYNG32 */

#ifdef TWSYNG32
#include "configs/msc-twsyn-interface.h"
#else
#include "configs/msc-interface.h"
#endif
