//#define TWSYNG32

/* interface.h.  Generated automatically by configure.  */
/* Define if you have EMACS interface. */
/* #undef IA_EMACS */

/* Define if you have GTK interface. */
/* #undef IA_GTK */

/* Define if you have KMIDI interface. */
/* #undef IA_KMIDI */

/* Define if you have MOTIF interface. */
/* #undef IA_MOTIF */

/* Define if you have NCURSES interface. */
/* #undef IA_NCURSES */

/* Define if you have PLUGIN interface. */
/* #undef IA_PLUGIN */

/* Define if you have SLANG interface. */
/* #undef IA_SLANG */

/* Define if you have TCLTK interface. */
/* #undef IA_TCLTK */

/* Define if you have VT100 interface. */
/* #undef IA_VT100 */

/* Define if you have XAW interface. */
/* #undef IA_XAW */

/* Define if you have XSKIN interface. */
/* #undef IA_XSKIN */

/* Define if you have DYNAMIC interface. */
/* #undef IA_DYNAMIC */

#ifdef TWSYNG32
/* Define if you have Windows32 GUI interface. */
/* #undef IA_W32GUI */

/* Define if you have Windows GUI synthesizer mode interface. */
#define IA_W32G_SYN 1
#else
/* Define if you have Windows32 GUI interface. */
#define IA_W32GUI 1

/* Define if you have Windows GUI synthesizer mode interface. */
/* #undef IA_W32G_SYN */
#endif

/* Define if you have Remote MIDI interface. */
/* #undef IA_SERVER */
