/* config.h.in.  Generated automatically from configure.in by autoheader.  */

#include "configs/msc-config.h"
